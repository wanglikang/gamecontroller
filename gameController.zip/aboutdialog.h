#ifndef ABOUTDIALOG_H
#define ABOUTDIALOG_H

#include <QDialog>

class AboutDialog : public QDialog
{
    Q_OBJECT
public:
    explicit AboutDialog(QWidget *parent = 0);
    void paintEvent(QPaintEvent *event);
signals:

public slots:

};

#endif // ABOUTDIALOG_H
