#include "cameradevice.h"

CameraDevice::CameraDevice(QObject *parent) : QObject(parent)
{

}
